from kivy.uix.boxlayout import BoxLayout

class MainWidget(BoxLayout):
    """
    Widget principal da aplicação
    """
    pass

